Inicio(desplieque de datos)

<table class="table table-ligth">

    <thead class="thead-light">
   
    <tr>
     <th> ID <th>    
    <th> Codigo <th>
    <th> Nombre <th>
    <th> a_paterno <th>
    <th> a_materno <th>
    <th> puesto <th>
    <th> sueldo <th>
     <th> tipo_moneda_sueldo <th>
    <th> correo <th>
    <th> activo <th>
   <th> eliminado <th>
    </tr>
    </thread>

    <tbody>
    @foreach($empleados as $empleado)
    <tr>
     <td>{{$loop-> iteration}} </td>
     <td>{{$empleado -> id}} </td>
     <td>{{$empleado -> codigo_empleado}} </td>
     <td>{{$empleado -> Nombre}} </td>
     <td>{{$empleado -> a_paterno}} </td>
     <td>{{$empleado -> a_materno}} </td>
     <td>{{$empleado -> puesto}} </td>
     <td>{{$empleado -> sueldo}} </td>
     <td>{{$empleado -> tipo_moneda_sueldo}} </td>
     <td>{{$empleado -> correo}} </td>
     <td>{{$empleado -> activo}} </td>
     <td>{{$empleado -> eliminado}} </td>     
     <td> Inactivar |

    <form method="post" action="{{ url('/empleados/'.$empleado->id)}}">
    {{csrf_field() }}
    {{method_field('DELETE') }}
    <button type="submit" onclick="return confirm('Inactivar?');"> Inactivar </button>
    </form>

     </td>

     @endforeach

</table>